﻿using Microsoft.Extensions.Hosting;

namespace TradingPlaces.WebApi.Services
{
    public interface IStrategyManagementService : IHostedService
    {
    }
}